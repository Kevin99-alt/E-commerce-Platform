$(document).ready(function(){
    
    $("#division").ready(function(){
		var url = "findward";
		$.post(url, 
			{
				division: $("#division").val()
			}, function(data){
			$("#ward").html(data);
		});
	});
    
	$("#division").change(function(){
		var url = "findward";
		$.post(url, 
			{
				division: $("#division").val()
			}, function(data){
			$("#ward").html(data);
		});
	});
});
