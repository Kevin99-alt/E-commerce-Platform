<div class="banner text-center">
  <div class="container">
    <h1>Get anything and <span class="segment-heading">everything on MCP </span>now!!</h1>
    <p>Mombasa County Portal</p>
    <a href="<?php link_page("post_ad"); ?>">Post Free Ad</a> </div>
</div>