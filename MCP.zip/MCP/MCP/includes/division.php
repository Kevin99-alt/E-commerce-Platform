<?php
require_once(INCLUDES."database.php");

class division extends DatabaseObject{
	public $id;
	public $division;
	protected static $db_fields = array("id", "division");
	protected static $table_name = "division";
	
	public function find_division_ward(){
		return ward::find_ward_by_division($this->id);
	}
}

?>