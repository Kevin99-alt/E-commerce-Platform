<?php
require_once(INCLUDES."database.php");

class ward extends DatabaseObject{
	public $id;
	public $division_id;
	public $ward;
	protected static $db_fields = array("id", "division_id", "ward");
	protected static $table_name = "ward";
	
	
	public static function find_ward_by_division($division_id){
		global $database;
		$id = $database->escape_value($division_id);
		$sql = "select * from ward where division_id = {$id}";
		return self::find_by_sql($sql);
	}
	
	public static function division_by_ward($ward_id){
		return ward::find_by_id($ward_id);
	}
	
	public static function file_products_by_ward($ward){
		$ward = self::find_by_id($ward);
		$users = User::find_users_by_ward($ward->id);
	}
}

?>