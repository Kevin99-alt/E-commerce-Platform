-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2022 at 06:44 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcp`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(3) NOT NULL,
  `title` varchar(70) NOT NULL,
  `slug` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`) VALUES
(1, 'Cars', 'cars'),
(2, 'Mobiles', 'mobiles'),
(3, 'Electronics and appliances', 'electronics'),
(4, 'Bikes', 'bikes'),
(5, 'Furniture', 'furniture'),
(6, 'Pets', 'pets'),
(8, 'Books, Sports and hobbies', 'books-sports-hobbies'),
(9, 'Fashion', 'fashion'),
(10, 'Services', 'services'),
(11, 'Real Estate', 'real-estate'),
(12, 'Kids', 'kids');

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE `division` (
  `id` int(10) NOT NULL,
  `division` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COMMENT='divisions in Mombasa';

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`id`, `division`) VALUES
(1, 'Changamwe'),
(2, 'Jomvu'),
(3, 'Kisauni'),
(4, 'Nyali'),
(5, 'Mvita');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `summary` text NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `category_id` int(3) NOT NULL,
  `views` bigint(20) NOT NULL,
  `upload_time` datetime(6) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `product_image` longtext NOT NULL,
  `region` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `slug`, `summary`, `user_id`, `category_id`, `views`, `upload_time`, `approved`, `featured`, `product_image`, `region`) VALUES
(141, 'Mountain', 345000, 'Mountain', 'Brand New', 42, 4, 34, '2022-10-12 05:16:15.000000', 1, 0, '[\"img_96602605016655445751900182684.jpg\",\"img_18213728271665544575868085227.jpg\",\"img_16432548616655445751389700535.jpg\",\"img_18103013261665544575309703880.\",\"img_12741252441665544575631937706.\",\"img_182579851816655445751671113429.\",\"img_85035819816655445751754790253.\"]', 14),
(142, 'Mercedes Benz', 4000000, 'Mercedes-Benz', 'Fairly Used', 43, 1, 5, '2022-10-12 05:26:02.000000', 1, 0, '[\"img_5334413791665545162453109266.jpg\",\"img_12291951601665545162790012556.jpg\",\"img_11207807491665545162378897659.jpg\",\"img_9933949261665545162693200071.\",\"img_209759314716655451621617754753.\",\"img_167131827416655451622096278837.\",\"img_200501101416655451622099670922.\"]', 16),
(143, 'Plumbing', 4500, 'Plumbing', 'Perfect handling', 43, 10, 3, '2022-10-12 07:32:03.000000', 1, 0, '[\"img_8058066671665552723260005430.jpg\",\"img_131514681816655527231773599654.jpg\",\"img_68031768316655527231323092927.jpg\",\"img_114732777016655527232124409175.\",\"img_650123333166555272398774567.\",\"img_4470829031665552723213038928.\",\"img_2385489981665552723483043667.\"]', 18),
(144, 'Nitro', 45000, 'Nitro', 'Brand new', 43, 4, 3, '2022-10-13 07:39:13.000000', 1, 0, '[\"img_5749801841665639553157057727.jpg\",\"img_9699728641665639553242722494.jpg\",\"img_154206015816656395531646338407.jpg\",\"img_781155951166563955360809518.\",\"img_11672685701665639553742987533.\",\"img_73175108316656395531637470369.\",\"img_13650344261665639553413218328.\"]', 14),
(145, 'SUV', 200000000, 'SUV', 'Brand New', 43, 1, 12, '2022-10-13 07:42:39.000000', 1, 0, '[\"img_200354207216656397591929097201.jpg\",\"img_7851211041665639759172029933.jpg\",\"img_3829692411665639759368746732.jpg\",\"img_17123216616656397591906838182.\",\"img_183349760016656397591882543370.\",\"img_7635807916656397591690855583.\",\"img_46170238416656397591820387319.\"]', 7),
(146, 'Oxford', 1000, 'Oxford', 'New Dictionary', 43, 8, 0, '2022-10-13 10:03:19.000000', 1, 0, '[\"img_121904387316656481991907560929.png\",\"img_1323290961166564819962127389.jpg\",\"img_48354853016656481991960784676.jpg\",\"img_10663130931665648199781934591.\",\"img_22308727716656481991767400484.\",\"img_19427539881665648199315416990.\",\"img_16111361681665648199382525369.\"]', 12),
(147, 'Bike', 200000, 'Bike', 'Brand new', 43, 4, 27, '2022-10-13 15:04:54.000000', 1, 0, '[\"img_6053759061665666294350903075.jpg\",\"img_73542646816656662941159813416.jpg\",\"img_3675754631665666294539692577.jpg\",\"img_49914931716656662941749903490.\",\"img_19913477851665666294208316322.\",\"img_16439562761665666294179478994.\",\"img_119559501716656662941500325407.\"]', 12),
(148, 'Cat', 5000, 'Cat', 'New', 43, 6, 0, '2022-10-13 15:36:10.000000', 1, 0, '[\"img_60667539116656681701472717085.jpg\",\"img_12034404131665668170886982641.jpg\",\"img_12165988481665668170215723576.jpg\",\"img_13178069241665668170791912633.\",\"img_11170790611665668170976672376.\",\"img_20065548391665668170364399603.\",\"img_12299731216656681701444620830.\"]', 19);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `full_name` varchar(255) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `is_admin`, `full_name`, `username`, `password`, `email`, `phone`) VALUES
(42, 0, 'Joel Mgaza', 'Joel', '2440c44d53994910427eb22ca2daa5eb4216b7c0', 'kevinmatuga99@gmail.com', '3423423423'),
(43, 0, 'Elizabeth Turu', 'Elizabeth', '789e218a33ff080da11fa81babc257f104390027', 'elizabethtu@gmail.com', '0728533072');

-- --------------------------------------------------------

--
-- Table structure for table `ward`
--

CREATE TABLE `ward` (
  `id` int(10) NOT NULL,
  `division_id` int(10) NOT NULL,
  `ward` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COMMENT='Mombasa';

--
-- Dumping data for table `ward`
--

INSERT INTO `ward` (`id`, `division_id`, `ward`) VALUES
(1, 1, 'Port Reitz'),
(2, 1, 'Kipevu'),
(3, 1, 'Airport'),
(4, 1, 'Changamwe'),
(5, 1, 'Chaani'),
(6, 2, 'Jomvu Kuu'),
(7, 2, 'Miritini'),
(8, 2, 'Mikindani'),
(9, 3, 'Mjambere'),
(10, 3, 'Junda'),
(11, 3, 'Mwakirunge'),
(12, 3, 'Mtopanga'),
(13, 3, 'Magogoni'),
(14, 3, 'Bamburi'),
(15, 3, 'Shanzu'),
(16, 4, 'Mtongwe'),
(17, 4, 'Shika Adabu'),
(18, 4, 'Bofu'),
(19, 4, 'Likoni'),
(20, 4, 'Tibwani'),
(21, 5, 'Mji wa Kale'),
(22, 5, 'Makadara'),
(23, 5, 'Tudor'),
(24, 5, 'Majengo'),
(25, 5, 'Ganjoni'),
(26, 5, 'Shimanzi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `index` (`region`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ward`
--
ALTER TABLE `ward`
  ADD PRIMARY KEY (`id`),
  ADD KEY `state_id` (`division_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `ward`
--
ALTER TABLE `ward`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
