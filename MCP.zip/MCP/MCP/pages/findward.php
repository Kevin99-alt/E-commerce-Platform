
<?php

if(isset($_POST['division']) && $_POST['division'] > 0){
	$division = (int)$_POST['division'];
	$wards = ward::find_ward_by_division($division);
}else{
	echo '<option value="0">Select ward</option>';
}
?>

<option value="0">Select ward</option>
<?php
foreach($wards as $ward):
?>

<option value="<?php echo $ward->id; ?>"><?php echo $ward->ward; ?></option>

<?php endforeach; ?>
